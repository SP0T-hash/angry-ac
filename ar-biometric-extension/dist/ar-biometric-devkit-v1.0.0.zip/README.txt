﻿AR Biometric Extension v1.0.0 -- Developer Kit
===================================================

Instalacao:
  1. Abra chrome://extensions
  2. Ative "Modo do desenvolvedor"
  3. Clique "Carregar sem compactacao" e selecione a pasta "extension"
  4. Copie o ID da extensao gerado
  5. Edite native-host-manifest/com.ar.biometric.host.json:
     - Substitua SUBSTITUA_PELO_ID_REAL_DA_EXTENSAO pelo ID real
     - Ajuste o caminho "path" para apontar para native-host/ArBiometricHost.exe
  6. Execute .\install.ps1 para registrar o native host

Native Host:
  - Requer .NET 8 Runtime instalado
  - Baixe em: https://dotnet.microsoft.com/download/dotnet/8.0
